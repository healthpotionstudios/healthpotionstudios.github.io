/*
Alex Wagner
WEB 150 - ASN #5
Business name: Smart Cookie Books
*/


function stars(stars){
    if (stars > 5) {
        stars = 5;
    }
    var str = "";
    var wholeStar = Math.floor(stars);

    for (var i = 0; i < wholeStar; i++) { 
        str += '<i class="fas fa-star"></i>';
    }
    var leftStars = 5 - wholeStar;
    if (wholeStar != stars) {
        str += '<i class="fas fa-star-half-alt"></i>';
        leftStars -= 1;
    }

    for (var i = 0; i < leftStars; i++) { 
        str += '<i class="far fa-star"></i>';
    }

    str += '<span>'
    str += Math.floor(Math.random() * 2000) + 400;  
    str +='</span>'

    document.write(str);
}

function fakeformsubmit()
{
    document.getElementById("form").style.display = "none";
    document.getElementById("submitted").innerText = "Thank you for contacting us. We usually can replay with 1-2 business days. Your ticket number is #" + (Math.floor(Math.random() * 20000) + 45689).toString() + ".";
}